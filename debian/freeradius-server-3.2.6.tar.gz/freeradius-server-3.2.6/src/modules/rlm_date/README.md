# rlm_date
## Metadata
<dl>
  <dt>category</dt><dd>policy</dd>
</dl>

## Summary

Converts date strings between user configurable formats.
