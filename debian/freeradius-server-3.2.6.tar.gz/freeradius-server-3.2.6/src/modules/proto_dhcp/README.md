# proto_dhcp
## Metadata
<dl>
  <dt>category</dt><dd>protocols</dd>
</dl>

## Summary

Implements the DHCP protocol for IPv4.
