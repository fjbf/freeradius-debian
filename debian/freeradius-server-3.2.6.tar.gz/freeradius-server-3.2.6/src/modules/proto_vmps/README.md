# proto_vmps
## Metadata
<dl>
  <dt>category</dt><dd>protocols</dd>
</dl>

## Summary

Implements the VLAN Management Policy Server (VMPS) protocol, as
used by Cisco switches to dynamically assign VLANs.
